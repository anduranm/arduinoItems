# ESP8266-WOL-From-Telegram
A device for triggering the WOL magic packet from Telegram
